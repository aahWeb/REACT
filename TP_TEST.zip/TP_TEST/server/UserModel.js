export default {
    "id": "",
    "gender": "",
    "firstname": "",
    "lastname": "",
    "email": "",
    "password": "",
    "phone": "",
    "birthdate": "",
    "city": "",
    "country": "",
    "photo": "",
    "category": "",
    "isAdmin": false
}