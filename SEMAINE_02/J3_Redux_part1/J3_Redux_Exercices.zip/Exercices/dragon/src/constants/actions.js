export const ADD_DRAGON = 'ADD_DRAGON';
export const SET_DRAGON = 'SET_DRAGON';
export const DELETE_DRAGON = 'DELETE_DRAGON';
export const REVERSE_DRAGON = 'REVERSE_DRAGON';