import "./App.css";

function Home() {
  return (
    <div className="App">
     HOME
    </div>
  );
}

export default Home;
