import "./App.css";

function Log() {
  return (
    <div className="App">
     LOG
    </div>
  );
}

export default Log;
