export const SWITCH_THEME = 'SWITCH_THEME';

export const SET_USER = 'SET_USER';

export const ADD_ITEM = 'ADD_ITEM';

export const CLEAR_BASKET = 'CLEAR_BASKET';

export const REMOVE_ITEM = 'REMOVE_ITEM';
